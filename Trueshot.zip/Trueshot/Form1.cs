﻿using FastColoredTextBoxNS;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using Microsoft.Web.WebView2.WinForms;

namespace Trueshot
{
    public partial class Form1 : Form
    {
        Timer time = new Timer();
        public Point mouseLocation;

        public Form1()
        {
            InitializeComponent();
            time.Tick += timertick;
            time.Start();
            

        }
        private void Form1_Load(object sender, EventArgs e)
        {
            this.webView21.Source =
        new Uri(Path.Combine(Application.StartupPath, @"Monaco\index.html"));
        }

        private void timertick(object sender, EventArgs e)
        {
            if (ForlornApi.Api.IsRobloxOpen())
            {
                robloxopen.Text = "Roblox Open: ✅";
                robloxopen.ForeColor = Color.LightGreen;  // Change text color to green
            }
            else
            {
                robloxopen.Text = "Roblox Open: ❌";
                robloxopen.ForeColor = Color.Red;  // Change text color to red
            }

            if (ForlornApi.Api.IsInjected())
            {
                status.Text = "Status: Injected!";
                status.ForeColor = Color.LightGreen;  // Change text color to green
            }
            else
            {
                status.Text = "Status: Not Injected!";
                status.ForeColor = Color.Red;  // Change text color to red
            }
        }



        private async void Execute_Click(object sender, EventArgs e)
        {
            Monaco module = new Monaco();
            string Execute = await module.GetText(webView21);
            ForlornApi.Api.ExecuteScript(Execute);
        }

        private void Inject_Click(object sender, EventArgs e)
        {
            ForlornApi.Api.Inject();
        }


        private void button1_Click(object sender, EventArgs e)
        {
            ForlornApi.Api.KillRoblox();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            ForlornApi.Api.SetAutoInject(true);
        }


   

        private void button3_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            mouseLocation = new Point(-e.X, -e.Y);
        }

        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                Point mousePose = Control.MousePosition;
                mousePose.Offset(mouseLocation.X, mouseLocation.Y);
                Location = mousePose;
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Monaco module = new Monaco();
            module.Clear(webView21);
        }
    }
}




     public class Monaco
{
    public async Task<string> GetText(WebView2 webv)
    {
        string str = await webv.ExecuteScriptAsync("btoa(window.editor.getValue())");
        string s = str.Replace("\"", "").Replace("\'", "");
        byte[] Buf = Convert.FromBase64String(s);
        string decoded = Encoding.UTF8.GetString(Buf);
        return decoded;
    }
    public async void Clear(WebView2 webv) // webview 2 errors are fixed like this
    {
        await webv.ExecuteScriptAsync("window.editor.setValue(\"\")");
    }
    public async void SetText(WebView2 webv, string text)
    {
        byte[] bytes = Encoding.UTF8.GetBytes(text);
        string Buf = Convert.ToBase64String(bytes);
        await webv.ExecuteScriptAsync($"window.editor.setValue(atob(\"{Buf}\"))");
    }
}