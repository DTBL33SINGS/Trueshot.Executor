﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Web.WebView2.WinForms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Shot.cc
{
    public partial class Form1 : Form
    {
        public Point mouseLocation;
        Timer time = new Timer();
        public Form1()
        {
            InitializeComponent();
            time.Tick += timertick;
            time.Start();
            Editor.Navigate(new Uri(string.Format("file:///{0}/Monaco/index.html", Directory.GetCurrentDirectory())));
        }

        private void timertick(object sender, EventArgs e)
        {

            if (ForlornApi.Api.IsInjected())
            {
                status.Text = "Status: Injected!";
                status.ForeColor = Color.LightGreen;  // Change text color to green
            }
            else
            {
                status.Text = "Status: Not Injected!";
                status.ForeColor = Color.Red;  // Change text color to red
            }
        }

        private void Inject_Click(object sender, EventArgs e)
        {
            ForlornApi.Api.Inject();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private  void Execute_Click(object sender, EventArgs e)
        {
            string script = Editor.Document.InvokeScript("getValue").ToString();
            ForlornApi.Api.ExecuteScript(script);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            ForlornApi.Api.KillRoblox();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            // Ensure the document is loaded and then invoke JavaScript to clear the editor
            if (Editor.Document != null)
            {
                Editor.Document.InvokeScript("eval", new object[] { "editor.setValue('')" });
            }
            else
            {
                MessageBox.Show("Editor document is not ready yet.");
            }

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            ForlornApi.Api.SetAutoInject(true);
        }

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            mouseLocation = new Point(-e.X, -e.Y);
        }

        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                Point mousePose = Control.MousePosition;
                mousePose.Offset(mouseLocation.X, mouseLocation.Y);
                Location = mousePose;
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            var Form2 = new Form2();
            Form2.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            var Form4 = new Form4();
            Form4.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            var Form3 = new Form3();
            Form3.Show();
        }
        private int tabCount = 1;
        private void button8_Click(object sender, EventArgs e)
        {
            TabPage newTab = new TabPage($"Tab {tabCount + 1}");

            WebBrowser webBrowser = new WebBrowser
            {
                Dock = DockStyle.Fill // Fill the tab with the WebBrowser
            };

            webBrowser.Navigate(new Uri(string.Format("file:///{0}/Monaco/index.html", Directory.GetCurrentDirectory())));
            newTab.Controls.Add(webBrowser);
            tabControl1.TabPages.Add(newTab);
            tabCount++;

        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (tabControl1.TabCount > 0 && tabControl1.SelectedTab != null)
            {
                if (tabControl1.TabCount > 1)
                {
                    if (MessageBox.Show("Are you sure you want to close this tab?", "Close Tab", MessageBoxButtons.YesNo) == DialogResult.Yes)
                    {
                        tabControl1.TabPages.Remove(tabControl1.SelectedTab);
                        tabCount--;
                    }
                }
                else
                {
                    MessageBox.Show("You cannot close the last tab.", "Error", MessageBoxButtons.OK);
                }
            }

        }
    }

    public class Monaco
    {
        public async Task<string> GetText(WebView2 webv)
        {
            string str = await webv.ExecuteScriptAsync("btoa(window.editor.getValue())");
            string s = str.Replace("\"", "").Replace("\'", "");
            byte[] Buf = Convert.FromBase64String(s);
            string decoded = Encoding.UTF8.GetString(Buf);
            return decoded;
        }
        public async void Clear(WebView2 webv) // webview 2 errors are fixed like this
        {
            await webv.ExecuteScriptAsync("window.editor.setValue(\"\")");
        }
        public async void SetText(WebView2 webv, string text)
        {
            byte[] bytes = Encoding.UTF8.GetBytes(text);
            string Buf = Convert.ToBase64String(bytes);
            await webv.ExecuteScriptAsync($"window.editor.setValue(atob(\"{Buf}\"))");
        }
    }
}